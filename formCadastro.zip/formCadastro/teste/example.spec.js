const { test, expect } = require('@playwright/test');

test.beforeEach(async ({ page }) => {
    await page.goto('file:///C:/Users/Aluno_Tarde/Desktop/formCadastro/index.html');
});

test('Teste 1 - Carregamento Inicial', async ({ page }) => {
    await expect(page.locator('h1')).toHaveText('Cadastro de Usuários');
    await expect(page.locator('#name')).toBeVisible();
    await expect(page.locator('#email')).toBeVisible();
    await expect(page.locator('#password')).toBeVisible();
    await expect(page.locator('button[type="submit"]')).toBeVisible();
});

test('Teste 2 - Validação de Campos Obrigatórios', async ({ page }) => {
    await page.waitForLoadState('domcontentloaded');
    await page.click('button[type="submit"]');
    const error = page.locator('#error-message');
    await expect(error).toHaveText('Por favor, preencha todos os campos.');
});

test('Teste 3 - Cadastro Bem-Sucedido', async ({ page }) => {
    await page.fill('#name', 'Lucas');
    await page.fill('#email', 'lucas@example.com');
    await page.fill('#password', '123456');
    await page.click('button[type="submit"]');

    const lista = page.locator('#user-list li');
    await expect(lista).toHaveCount(1);
    await expect(lista.first()).toContainText('Lucas');
});

test('Teste 4 - Evitar Cadastros Duplicados', async ({ page }) => {
    const nome = 'Lucas';
    const email = 'lucas@example.com';

    // Primeiro cadastro
    await page.fill('#name', nome);
    await page.fill('#email', email);
    await page.fill('#password', '123456');
    await page.click('button[type="submit"]');

    // Tentando cadastrar igual
    await page.fill('#name', nome);
    await page.fill('#email', email);
    await page.fill('#password', '123456');
    await page.click('button[type="submit"]');

    const lista = page.locator('#user-list li');
    await expect(lista).toHaveCount(1);
});

test('Teste 5 - Limpar Lista de Cadastros', async ({ page }) => {
    await page.fill('#name', 'Lucas');
    await page.fill('#email', 'lucas@example.com');
    await page.fill('#password', '123456');
    await page.click('button[type="submit"]');

    await page.click('#clear-list');

    const lista = page.locator('#user-list li');
    await expect(lista).toHaveCount(0);
});